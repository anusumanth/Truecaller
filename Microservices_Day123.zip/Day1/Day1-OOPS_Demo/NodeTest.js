console.log("Happy Gowri & Ganesha !!!!!");

customerObject = new Object();
customerObject.ID = 34262829
customerObject.Name = "RPS"

console.log(customerObject);



