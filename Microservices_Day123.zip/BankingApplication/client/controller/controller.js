savingmodule.controller('SavingsCtr',['$scope',function($scope){
        $scope.account={
            accountId:5673891038473,
            balance:2017,
            type:'Savings',
            startDate:new Date(2007,11,11)
        }

        $scope.accountSubmit=function ()
        {
          console.log($scope.account);
        }
    }]);
savingmodule.controller('CustomerCtrl',['$scope','$http',
    function ($scope,$http)
    {
        $http({

            method:'GET',
            datatype:"json",
            headers:{
                'Content-Type':'application/json'
            },
            url:'http://localhost:7000/Retrieve'

        }).then(function(response)

        {
            console.log(response);
            $scope.customerdata=response.data;
        })


    }])