package com.anz.banking.dao;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.anz.banking.models.Loan;

@Repository
public class LoanSearchRepository {
	
	@Autowired
	MongoTemplate mongoTemplate;
	
	public Collection getLoanByQuery(String text)
	{
		return mongoTemplate.find(Query.query(new Criteria().orOperator(Criteria.where("loannumber").regex(text,"i"),
																					  Criteria.where("lonatype").regex(text,"i"),
																					  Criteria.where("loanamount").regex(text,"i"))
																						),Loan.class);
	}
	

}
