/**
 * Created by BALASUBRAMANIAM on 24/08/2017.
 */
//Immediate Invocation of Function Expression
invoke=function()
{
   for(i=0;i<100;i++)
    console.log(Math.random())


}();